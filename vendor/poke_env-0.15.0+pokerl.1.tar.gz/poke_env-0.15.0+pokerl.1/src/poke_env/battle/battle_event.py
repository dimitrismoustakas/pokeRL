"""Bounded, perspective-public battle events for decision-time consumers."""

from dataclasses import dataclass
from enum import Enum


class PublicBattleEventKind(str, Enum):
    """High-level Showdown events that are public to the receiving player."""

    MOVE = "move"
    SWITCH = "switch"
    DRAG = "drag"
    CANT = "cant"
    FAINT = "faint"
    TERA = "tera"


@dataclass(frozen=True, slots=True)
class PublicMoveTargetOutcome:
    """Public protocol facts for one target reached by a move.

    These fields deliberately preserve observations rather than assigning a
    strategic value to them.  In particular, an unmarked target simply passed
    the public interaction checks; it does not imply damage or a good move.
    """

    target: str
    # True only when this target was declared by the major ``move`` line.
    # Minor protocol lines can mention the acting slot while describing an
    # action-level failure; consumers must not mistake that mention for move
    # routing.
    declared_on_move_line: bool = False
    missed: bool = False
    immune: bool = False
    blocked_by: str | None = None
    failed: bool = False
    failed_action: str | None = None
    hit_count: int | None = None
    activations: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class PublicBattleEvent:
    """One immutable event exactly as publicly observed by this battle view."""

    kind: PublicBattleEventKind
    actor: str
    target: str | None = None
    move: str | None = None
    details: str | None = None
    failed: bool = False
    missed: bool = False
    spread: bool = False
    no_target: bool = False
    action_failed: bool = False
    source_effect: str | None = None
    target_outcomes: tuple[PublicMoveTargetOutcome, ...] = ()


@dataclass(frozen=True, slots=True)
class PublicBattleEventSegment:
    """Most recent complete turn, terminal turn, or partial mid-turn segment."""

    events: tuple[PublicBattleEvent, ...]
    turn: int
    partial: bool
    overflow_count: int = 0

    @property
    def valid(self) -> bool:
        return bool(self.events or self.overflow_count)
